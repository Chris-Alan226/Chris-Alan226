// ---------------Menu Hamburger---------------
// Ce script gère l'affichage d'un menu hamburger sur un site web.
// Il permet d'ouvrir et de fermer le menu en cliquant sur l'icône hamburger,
// sur un bouton de fermeture ou en cliquant à l'extérieur du menu.
// Il permet également de fermer le menu en appuyant sur la touche Échap.
// Il bloque le défilement de la page lorsque le menu est ouvert.
document.addEventListener('DOMContentLoaded', function() {
    // Éléments DOM
    const hamburger = document.querySelector('.hamburger');
    const menu = document.querySelector('.menu');
    const overlay = document.querySelector('.menu-overlay');
    const closeBtn = document.querySelector('.close-btn');
    const menuLinks = document.querySelectorAll('.menu a');
    
    // Fonction de basculement du menu
    const toggleMenu = () => {
        menu.classList.toggle('active');
        overlay.classList.toggle('active');
        document.body.classList.toggle('no-scroll'); // Bloquer le défilement
    };

    // Gestionnaires d'événements
    hamburger.addEventListener('click', (e) => {
        e.stopPropagation(); // Empêche la propagation à document
        toggleMenu();
    });

    closeBtn.addEventListener('click', toggleMenu);
    overlay.addEventListener('click', toggleMenu);

    // Fermer le menu après clic sur un lien
    menuLinks.forEach(link => {
        link.addEventListener('click', toggleMenu);
    });

    // Fermer le menu en cliquant à l'extérieur
    document.addEventListener('click', (e) => {
        if (menu.classList.contains('active')) {
            const isClickInside = menu.contains(e.target) || hamburger.contains(e.target);
            if (!isClickInside) {
                toggleMenu();
            }
        }
    });

    // Fermer avec la touche Escape
    document.addEventListener('keydown', (e) => {
        if (e.key === 'Escape' && menu.classList.contains('active')) {
            toggleMenu();
        }
    });
});


// ---------------carousel---------------
// Ce script gère un carrousel d'images sur un site web.
// Il permet de faire défiler les images automatiquement,
// de les faire défiler manuellement avec des boutons,
// et de faire défiler les images avec la molette de la souris.
document.addEventListener('DOMContentLoaded', function() {
    const track = document.querySelector('.carousel-track');
    const articles = document.querySelectorAll('.carousel-track article');
    const nextBtn = document.querySelector('.next');
    const prevBtn = document.querySelector('.prev');
    let currentIndex = 0;
    let intervalId;
    const articleWidth = articles[0].offsetWidth + 20; // Largeur + marge

    function moveToIndex(index) {
        currentIndex = index;
        track.style.transform = `translateX(-${currentIndex * articleWidth}px)`;
        updateButtons();
    }

    function nextSlide() {
        if (currentIndex < articles.length - 1) {
            moveToIndex(currentIndex + 1);
        } else {
            moveToIndex(0); // Retour au début
        }
    }

    function prevSlide() {
        if (currentIndex > 0) {
            moveToIndex(currentIndex - 1);
        } else {
            moveToIndex(articles.length - 1); // Aller à la fin
        }
    }

    function updateButtons() {
        prevBtn.style.visibility = currentIndex === 0 ? 'hidden' : 'visible';
        nextBtn.style.visibility = currentIndex >= articles.length - 1 ? 'hidden' : 'visible';
    }

    function startAutoSlide() {
        intervalId = setInterval(nextSlide, 3000); // Change toutes les 3 secondes
    }

    function stopAutoSlide() {
        clearInterval(intervalId);
    }

    // Événements
    nextBtn.addEventListener('click', () => {
        stopAutoSlide();
        nextSlide();
        startAutoSlide();
    });

    prevBtn.addEventListener('click', () => {
        stopAutoSlide();
        prevSlide();
        startAutoSlide();
    });

    // Pause au survol
    document.querySelector('.carousel-container').addEventListener('mouseenter', stopAutoSlide);
    document.querySelector('.carousel-container').addEventListener('mouseleave', startAutoSlide);

    // Démarrer l'auto-défilement
    startAutoSlide();
    updateButtons();
});
